def get_busy_slots():
    return "10:00–12:00 and 15:00–16:00 tomorrow"
